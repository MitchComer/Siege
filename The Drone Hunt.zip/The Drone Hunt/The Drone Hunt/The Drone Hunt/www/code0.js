gdjs.NewSceneCode = {};
gdjs.NewSceneCode.forEachIndex2 = 0;

gdjs.NewSceneCode.forEachObjects2 = [];

gdjs.NewSceneCode.forEachTemporary2 = null;

gdjs.NewSceneCode.forEachTotalCount2 = 0;

gdjs.NewSceneCode.GDEchoObjects1= [];
gdjs.NewSceneCode.GDEchoObjects2= [];
gdjs.NewSceneCode.GDDroneObjects1= [];
gdjs.NewSceneCode.GDDroneObjects2= [];
gdjs.NewSceneCode.GDBulletObjects1= [];
gdjs.NewSceneCode.GDBulletObjects2= [];
gdjs.NewSceneCode.GDBullet2Objects1= [];
gdjs.NewSceneCode.GDBullet2Objects2= [];
gdjs.NewSceneCode.GDExplosionObjects1= [];
gdjs.NewSceneCode.GDExplosionObjects2= [];
gdjs.NewSceneCode.GDGameOverObjects1= [];
gdjs.NewSceneCode.GDGameOverObjects2= [];
gdjs.NewSceneCode.GDScoreObjects1= [];
gdjs.NewSceneCode.GDScoreObjects2= [];
gdjs.NewSceneCode.GDAltBack2Objects1= [];
gdjs.NewSceneCode.GDAltBack2Objects2= [];
gdjs.NewSceneCode.GDAltBack1Objects1= [];
gdjs.NewSceneCode.GDAltBack1Objects2= [];
gdjs.NewSceneCode.GDBackgroundObjects1= [];
gdjs.NewSceneCode.GDBackgroundObjects2= [];
gdjs.NewSceneCode.GDIntroObjects1= [];
gdjs.NewSceneCode.GDIntroObjects2= [];
gdjs.NewSceneCode.GDNitroObjects1= [];
gdjs.NewSceneCode.GDNitroObjects2= [];
gdjs.NewSceneCode.GDBatteryObjects1= [];
gdjs.NewSceneCode.GDBatteryObjects2= [];
gdjs.NewSceneCode.GDStockObjects1= [];
gdjs.NewSceneCode.GDStockObjects2= [];
gdjs.NewSceneCode.GDTowerObjects1= [];
gdjs.NewSceneCode.GDTowerObjects2= [];
gdjs.NewSceneCode.GDHouseObjects1= [];
gdjs.NewSceneCode.GDHouseObjects2= [];

gdjs.NewSceneCode.conditionTrue_0 = {val:false};
gdjs.NewSceneCode.condition0IsTrue_0 = {val:false};
gdjs.NewSceneCode.condition1IsTrue_0 = {val:false};
gdjs.NewSceneCode.condition2IsTrue_0 = {val:false};
gdjs.NewSceneCode.condition3IsTrue_0 = {val:false};


gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDIntroObjects1Objects = Hashtable.newFrom({"Intro": gdjs.NewSceneCode.GDIntroObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDTowerObjects1Objects = Hashtable.newFrom({"Tower": gdjs.NewSceneCode.GDTowerObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDAltBack1Objects1Objects = Hashtable.newFrom({"AltBack1": gdjs.NewSceneCode.GDAltBack1Objects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDHouseObjects1Objects = Hashtable.newFrom({"House": gdjs.NewSceneCode.GDHouseObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDAltBack2Objects1Objects = Hashtable.newFrom({"AltBack2": gdjs.NewSceneCode.GDAltBack2Objects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDIntroObjects1Objects = Hashtable.newFrom({"Intro": gdjs.NewSceneCode.GDIntroObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.NewSceneCode.GDBulletObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDNitroObjects1Objects = Hashtable.newFrom({"Nitro": gdjs.NewSceneCode.GDNitroObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.NewSceneCode.GDBulletObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDNitroObjects1Objects = Hashtable.newFrom({"Nitro": gdjs.NewSceneCode.GDNitroObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDExplosionObjects1Objects = Hashtable.newFrom({"Explosion": gdjs.NewSceneCode.GDExplosionObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDExplosionObjects1Objects = Hashtable.newFrom({"Explosion": gdjs.NewSceneCode.GDExplosionObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDExplosionObjects1Objects = Hashtable.newFrom({"Explosion": gdjs.NewSceneCode.GDExplosionObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDExplosionObjects1Objects = Hashtable.newFrom({"Explosion": gdjs.NewSceneCode.GDExplosionObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDExplosionObjects1Objects = Hashtable.newFrom({"Explosion": gdjs.NewSceneCode.GDExplosionObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDExplosionObjects1Objects = Hashtable.newFrom({"Explosion": gdjs.NewSceneCode.GDExplosionObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDExplosionObjects1Objects = Hashtable.newFrom({"Explosion": gdjs.NewSceneCode.GDExplosionObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDExplosionObjects1Objects = Hashtable.newFrom({"Explosion": gdjs.NewSceneCode.GDExplosionObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDExplosionObjects1Objects = Hashtable.newFrom({"Explosion": gdjs.NewSceneCode.GDExplosionObjects1});gdjs.NewSceneCode.eventsList0x69aadc = function(runtimeScene) {

}; //End of gdjs.NewSceneCode.eventsList0x69aadc
gdjs.NewSceneCode.eventsList0x77973c = function(runtimeScene) {

{

/* Reuse gdjs.NewSceneCode.GDDroneObjects1 */

for(gdjs.NewSceneCode.forEachIndex2 = 0;gdjs.NewSceneCode.forEachIndex2 < gdjs.NewSceneCode.GDDroneObjects1.length;++gdjs.NewSceneCode.forEachIndex2) {
gdjs.NewSceneCode.GDDroneObjects2.length = 0;


gdjs.NewSceneCode.forEachTemporary2 = gdjs.NewSceneCode.GDDroneObjects1[gdjs.NewSceneCode.forEachIndex2];
gdjs.NewSceneCode.GDDroneObjects2.push(gdjs.NewSceneCode.forEachTemporary2);
if (true) {
{runtimeScene.getVariables().getFromIndex(0).add(1);
}}
}

}


}; //End of gdjs.NewSceneCode.eventsList0x77973c
gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDNitroObjects1Objects = Hashtable.newFrom({"Nitro": gdjs.NewSceneCode.GDNitroObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDEchoObjects1Objects = Hashtable.newFrom({"Echo": gdjs.NewSceneCode.GDEchoObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDBatteryObjects1Objects = Hashtable.newFrom({"Battery": gdjs.NewSceneCode.GDBatteryObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.NewSceneCode.GDBulletObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDBatteryObjects1Objects = Hashtable.newFrom({"Battery": gdjs.NewSceneCode.GDBatteryObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDBullet2Objects1Objects = Hashtable.newFrom({"Bullet2": gdjs.NewSceneCode.GDBullet2Objects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDBatteryObjects1Objects = Hashtable.newFrom({"Battery": gdjs.NewSceneCode.GDBatteryObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDEchoObjects1Objects = Hashtable.newFrom({"Echo": gdjs.NewSceneCode.GDEchoObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDBullet2Objects1Objects = Hashtable.newFrom({"Bullet2": gdjs.NewSceneCode.GDBullet2Objects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDExplosionObjects1Objects = Hashtable.newFrom({"Explosion": gdjs.NewSceneCode.GDExplosionObjects1});gdjs.NewSceneCode.eventsList0x6fae84 = function(runtimeScene) {

}; //End of gdjs.NewSceneCode.eventsList0x6fae84
gdjs.NewSceneCode.eventsList0x707bf4 = function(runtimeScene) {

{

/* Reuse gdjs.NewSceneCode.GDDroneObjects1 */

for(gdjs.NewSceneCode.forEachIndex2 = 0;gdjs.NewSceneCode.forEachIndex2 < gdjs.NewSceneCode.GDDroneObjects1.length;++gdjs.NewSceneCode.forEachIndex2) {
gdjs.NewSceneCode.GDDroneObjects2.length = 0;


gdjs.NewSceneCode.forEachTemporary2 = gdjs.NewSceneCode.GDDroneObjects1[gdjs.NewSceneCode.forEachIndex2];
gdjs.NewSceneCode.GDDroneObjects2.push(gdjs.NewSceneCode.forEachTemporary2);
if (true) {
{runtimeScene.getVariables().getFromIndex(0).add(1);
}}
}

}


}; //End of gdjs.NewSceneCode.eventsList0x707bf4
gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDBulletObjects1Objects = Hashtable.newFrom({"Bullet": gdjs.NewSceneCode.GDBulletObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDExplosionObjects1Objects = Hashtable.newFrom({"Explosion": gdjs.NewSceneCode.GDExplosionObjects1});gdjs.NewSceneCode.eventsList0x781afc = function(runtimeScene) {

}; //End of gdjs.NewSceneCode.eventsList0x781afc
gdjs.NewSceneCode.eventsList0x6fafe4 = function(runtimeScene) {

{

/* Reuse gdjs.NewSceneCode.GDDroneObjects1 */

for(gdjs.NewSceneCode.forEachIndex2 = 0;gdjs.NewSceneCode.forEachIndex2 < gdjs.NewSceneCode.GDDroneObjects1.length;++gdjs.NewSceneCode.forEachIndex2) {
gdjs.NewSceneCode.GDDroneObjects2.length = 0;


gdjs.NewSceneCode.forEachTemporary2 = gdjs.NewSceneCode.GDDroneObjects1[gdjs.NewSceneCode.forEachIndex2];
gdjs.NewSceneCode.GDDroneObjects2.push(gdjs.NewSceneCode.forEachTemporary2);
if (true) {
{runtimeScene.getVariables().getFromIndex(0).add(1);
}}
}

}


}; //End of gdjs.NewSceneCode.eventsList0x6fafe4
gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects = Hashtable.newFrom({"Drone": gdjs.NewSceneCode.GDDroneObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDEchoObjects1Objects = Hashtable.newFrom({"Echo": gdjs.NewSceneCode.GDEchoObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDExplosionObjects1Objects = Hashtable.newFrom({"Explosion": gdjs.NewSceneCode.GDExplosionObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDGameOverObjects1Objects = Hashtable.newFrom({"GameOver": gdjs.NewSceneCode.GDGameOverObjects1});gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDEchoObjects1Objects = Hashtable.newFrom({"Echo": gdjs.NewSceneCode.GDEchoObjects1});gdjs.NewSceneCode.eventsList0xb4320 = function(runtimeScene) {

{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.NewSceneCode.GDIntroObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDIntroObjects1Objects, 0, 0, "");
}{for(var i = 0, len = gdjs.NewSceneCode.GDIntroObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDIntroObjects1[i].hide(false);
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}}

}


{

gdjs.NewSceneCode.GDTowerObjects1.createFrom(runtimeScene.getObjects("Tower"));

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
gdjs.NewSceneCode.condition1IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDTowerObjects1Objects, runtimeScene, true, false);
}if ( gdjs.NewSceneCode.condition0IsTrue_0.val ) {
{
gdjs.NewSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.NewSceneCode.condition1IsTrue_0.val) {
gdjs.NewSceneCode.GDAltBack1Objects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDAltBack1Objects1Objects, 0, 0, "Background");
}}

}


{

gdjs.NewSceneCode.GDHouseObjects1.createFrom(runtimeScene.getObjects("House"));

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
gdjs.NewSceneCode.condition1IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDHouseObjects1Objects, runtimeScene, true, false);
}if ( gdjs.NewSceneCode.condition0IsTrue_0.val ) {
{
gdjs.NewSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.NewSceneCode.condition1IsTrue_0.val) {
gdjs.NewSceneCode.GDAltBack2Objects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDAltBack2Objects1Objects, 0, 0, "Background");
}}

}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.NewSceneCode.GDHouseObjects1.createFrom(runtimeScene.getObjects("House"));
gdjs.NewSceneCode.GDIntroObjects1.createFrom(runtimeScene.getObjects("Intro"));
gdjs.NewSceneCode.GDStockObjects1.createFrom(runtimeScene.getObjects("Stock"));
gdjs.NewSceneCode.GDTowerObjects1.createFrom(runtimeScene.getObjects("Tower"));
{for(var i = 0, len = gdjs.NewSceneCode.GDIntroObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDIntroObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDIntroObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDIntroObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDStockObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDStockObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDTowerObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDTowerObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDHouseObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDHouseObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.NewSceneCode.GDIntroObjects1.createFrom(runtimeScene.getObjects("Intro"));

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDIntroObjects1Objects) == 0;
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}}

}


{


{
{gdjs.adMob.loadBanner("ca-app-pub-6927019777720724/9260605326", "", true, true, true, true);
}}

}


{


{
gdjs.NewSceneCode.GDEchoObjects1.createFrom(runtimeScene.getObjects("Echo"));
{for(var i = 0, len = gdjs.NewSceneCode.GDEchoObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDEchoObjects1[i].rotateTowardPosition(gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0), 0, runtimeScene);
}
}}

}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
gdjs.NewSceneCode.condition1IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.NewSceneCode.condition0IsTrue_0.val ) {
{
gdjs.NewSceneCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.25, "Firerate");
}}
if (gdjs.NewSceneCode.condition1IsTrue_0.val) {
gdjs.NewSceneCode.GDEchoObjects1.createFrom(runtimeScene.getObjects("Echo"));
gdjs.NewSceneCode.GDBulletObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDBulletObjects1Objects, (( gdjs.NewSceneCode.GDEchoObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDEchoObjects1[0].getPointX("Canon")), (( gdjs.NewSceneCode.GDEchoObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDEchoObjects1[0].getPointY("Canon")), "");
}{for(var i = 0, len = gdjs.NewSceneCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDBulletObjects1[i].addPolarForce((( gdjs.NewSceneCode.GDEchoObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDEchoObjects1[0].getAngle()), 400, 1);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Firerate");
}}

}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 1, "EnemyCreation");
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.NewSceneCode.GDDroneObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "EnemyCreation");
}}

}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 10, "Level2");
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.NewSceneCode.GDDroneObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Level2");
}}

}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 20, "Level3");
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.NewSceneCode.GDDroneObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Level3");
}}

}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 5, "Level4");
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.NewSceneCode.GDDroneObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Level4");
}}

}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 30, "Level5");
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.NewSceneCode.GDDroneObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Level5");
}}

}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 36, "Level6");
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.NewSceneCode.GDDroneObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Level6");
}}

}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 42, "Level7");
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.NewSceneCode.GDDroneObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Level7");
}}

}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 53, "Level8");
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.NewSceneCode.GDDroneObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Level8");
}}

}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 75, "Level9");
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.NewSceneCode.GDDroneObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Level9");
}}

}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 3, "Level10");
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.NewSceneCode.GDDroneObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Level10");
}}

}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 7, "Level11");
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.NewSceneCode.GDDroneObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Level11");
}}

}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 70, "Level12");
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.NewSceneCode.GDDroneObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Level12");
}}

}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 35, "Nitro");
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.NewSceneCode.GDNitroObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDNitroObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Nitro");
}}

}


{


{
gdjs.NewSceneCode.GDEchoObjects1.createFrom(runtimeScene.getObjects("Echo"));
gdjs.NewSceneCode.GDNitroObjects1.createFrom(runtimeScene.getObjects("Nitro"));
{for(var i = 0, len = gdjs.NewSceneCode.GDNitroObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDNitroObjects1[i].addForceTowardObject((gdjs.NewSceneCode.GDEchoObjects1.length !== 0 ? gdjs.NewSceneCode.GDEchoObjects1[0] : null), 400, 0);
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDNitroObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDNitroObjects1[i].rotateTowardPosition((( gdjs.NewSceneCode.GDEchoObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDEchoObjects1[0].getPointX("Centre")), (( gdjs.NewSceneCode.GDEchoObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDEchoObjects1[0].getPointY("Centre")), 0, runtimeScene);
}
}}

}


{

gdjs.NewSceneCode.GDBulletObjects1.createFrom(runtimeScene.getObjects("Bullet"));
gdjs.NewSceneCode.GDNitroObjects1.createFrom(runtimeScene.getObjects("Nitro"));

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDBulletObjects1Objects, gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDNitroObjects1Objects, false, runtimeScene, false);
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.NewSceneCode.GDBulletObjects1 */
gdjs.NewSceneCode.GDDroneObjects1.createFrom(runtimeScene.getObjects("Drone"));
/* Reuse gdjs.NewSceneCode.GDNitroObjects1 */
gdjs.NewSceneCode.GDExplosionObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDExplosionObjects1Objects, (( gdjs.NewSceneCode.GDNitroObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDNitroObjects1[0].getPointX("Centre")), (( gdjs.NewSceneCode.GDNitroObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDNitroObjects1[0].getPointY("Centre")), "");
}{for(var i = 0, len = gdjs.NewSceneCode.GDNitroObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDNitroObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDBulletObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDExplosionObjects1Objects, (( gdjs.NewSceneCode.GDDroneObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDDroneObjects1[0].getPointX("Centre")), (( gdjs.NewSceneCode.GDDroneObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDDroneObjects1[0].getPointY("Centre")), "");
}{for(var i = 0, len = gdjs.NewSceneCode.GDDroneObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDDroneObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDExplosionObjects1Objects, (( gdjs.NewSceneCode.GDDroneObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDDroneObjects1[0].getPointX("Centre")), (( gdjs.NewSceneCode.GDDroneObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDDroneObjects1[0].getPointY("Centre")), "");
}{for(var i = 0, len = gdjs.NewSceneCode.GDDroneObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDDroneObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDExplosionObjects1Objects, (( gdjs.NewSceneCode.GDDroneObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDDroneObjects1[0].getPointX("Centre")), (( gdjs.NewSceneCode.GDDroneObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDDroneObjects1[0].getPointY("Centre")), "");
}{for(var i = 0, len = gdjs.NewSceneCode.GDDroneObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDDroneObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDExplosionObjects1Objects, (( gdjs.NewSceneCode.GDDroneObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDDroneObjects1[0].getPointX("Centre")), (( gdjs.NewSceneCode.GDDroneObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDDroneObjects1[0].getPointY("Centre")), "");
}{for(var i = 0, len = gdjs.NewSceneCode.GDDroneObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDDroneObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDExplosionObjects1Objects, (( gdjs.NewSceneCode.GDDroneObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDDroneObjects1[0].getPointX("Centre")), (( gdjs.NewSceneCode.GDDroneObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDDroneObjects1[0].getPointY("Centre")), "");
}{for(var i = 0, len = gdjs.NewSceneCode.GDDroneObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDDroneObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDExplosionObjects1Objects, (( gdjs.NewSceneCode.GDDroneObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDDroneObjects1[0].getPointX("Centre")), (( gdjs.NewSceneCode.GDDroneObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDDroneObjects1[0].getPointY("Centre")), "");
}{for(var i = 0, len = gdjs.NewSceneCode.GDDroneObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDDroneObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDExplosionObjects1Objects, (( gdjs.NewSceneCode.GDDroneObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDDroneObjects1[0].getPointX("Centre")), (( gdjs.NewSceneCode.GDDroneObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDDroneObjects1[0].getPointY("Centre")), "");
}{for(var i = 0, len = gdjs.NewSceneCode.GDDroneObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDDroneObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDExplosionObjects1Objects, (( gdjs.NewSceneCode.GDDroneObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDDroneObjects1[0].getPointX("Centre")), (( gdjs.NewSceneCode.GDDroneObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDDroneObjects1[0].getPointY("Centre")), "");
}{for(var i = 0, len = gdjs.NewSceneCode.GDDroneObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDDroneObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.NewSceneCode.eventsList0x77973c(runtimeScene);} //End of subevents
}

}


{

gdjs.NewSceneCode.GDEchoObjects1.createFrom(runtimeScene.getObjects("Echo"));
gdjs.NewSceneCode.GDNitroObjects1.createFrom(runtimeScene.getObjects("Nitro"));

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDNitroObjects1Objects, gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDEchoObjects1Objects, false, runtimeScene, false);
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.NewSceneCode.GDNitroObjects1 */
gdjs.NewSceneCode.GDDroneObjects1.length = 0;

{for(var i = 0, len = gdjs.NewSceneCode.GDNitroObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDNitroObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}}

}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 9.3, "Bandit");
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.NewSceneCode.GDBatteryObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDBatteryObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Bandit");
}}

}


{


{
gdjs.NewSceneCode.GDBatteryObjects1.createFrom(runtimeScene.getObjects("Battery"));
gdjs.NewSceneCode.GDEchoObjects1.createFrom(runtimeScene.getObjects("Echo"));
{for(var i = 0, len = gdjs.NewSceneCode.GDBatteryObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDBatteryObjects1[i].addForceTowardObject((gdjs.NewSceneCode.GDEchoObjects1.length !== 0 ? gdjs.NewSceneCode.GDEchoObjects1[0] : null), 500, 0);
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDBatteryObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDBatteryObjects1[i].rotateTowardPosition((( gdjs.NewSceneCode.GDEchoObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDEchoObjects1[0].getPointX("Centre")), (( gdjs.NewSceneCode.GDEchoObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDEchoObjects1[0].getPointY("Centre")), 0, runtimeScene);
}
}}

}


{

gdjs.NewSceneCode.GDBatteryObjects1.createFrom(runtimeScene.getObjects("Battery"));
gdjs.NewSceneCode.GDBulletObjects1.createFrom(runtimeScene.getObjects("Bullet"));

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
gdjs.NewSceneCode.condition1IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDBulletObjects1Objects, gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDBatteryObjects1Objects, false, runtimeScene, false);
}if ( gdjs.NewSceneCode.condition0IsTrue_0.val ) {
{
gdjs.NewSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
if (gdjs.NewSceneCode.condition1IsTrue_0.val) {
/* Reuse gdjs.NewSceneCode.GDBatteryObjects1 */
gdjs.NewSceneCode.GDEchoObjects1.createFrom(runtimeScene.getObjects("Echo"));
gdjs.NewSceneCode.GDBullet2Objects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDBullet2Objects1Objects, (( gdjs.NewSceneCode.GDEchoObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDEchoObjects1[0].getPointX("Canon")), (( gdjs.NewSceneCode.GDEchoObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDEchoObjects1[0].getPointY("Canon")), "");
}{for(var i = 0, len = gdjs.NewSceneCode.GDBullet2Objects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDBullet2Objects1[i].addPolarForce((( gdjs.NewSceneCode.GDEchoObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDEchoObjects1[0].getAngle()), 100, 1);
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDBatteryObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDBatteryObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.NewSceneCode.GDBatteryObjects1.createFrom(runtimeScene.getObjects("Battery"));
gdjs.NewSceneCode.GDEchoObjects1.createFrom(runtimeScene.getObjects("Echo"));

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDBatteryObjects1Objects, gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDEchoObjects1Objects, false, runtimeScene, false);
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.NewSceneCode.GDBatteryObjects1 */
gdjs.NewSceneCode.GDDroneObjects1.length = 0;

{for(var i = 0, len = gdjs.NewSceneCode.GDBatteryObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDBatteryObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.random(800), -(50), "");
}}

}


{


{
}

}


{


{
gdjs.NewSceneCode.GDDroneObjects1.createFrom(runtimeScene.getObjects("Drone"));
gdjs.NewSceneCode.GDEchoObjects1.createFrom(runtimeScene.getObjects("Echo"));
{for(var i = 0, len = gdjs.NewSceneCode.GDDroneObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDDroneObjects1[i].addForceTowardObject((gdjs.NewSceneCode.GDEchoObjects1.length !== 0 ? gdjs.NewSceneCode.GDEchoObjects1[0] : null), 150, 0);
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDDroneObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDDroneObjects1[i].rotateTowardPosition((( gdjs.NewSceneCode.GDEchoObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDEchoObjects1[0].getPointX("Centre")), (( gdjs.NewSceneCode.GDEchoObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDEchoObjects1[0].getPointY("Centre")), 0, runtimeScene);
}
}}

}


{

gdjs.NewSceneCode.GDBullet2Objects1.createFrom(runtimeScene.getObjects("Bullet2"));
gdjs.NewSceneCode.GDDroneObjects1.createFrom(runtimeScene.getObjects("Drone"));

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDBullet2Objects1Objects, gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, false, runtimeScene, false);
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.NewSceneCode.GDDroneObjects1 */
gdjs.NewSceneCode.GDExplosionObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDExplosionObjects1Objects, (( gdjs.NewSceneCode.GDDroneObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDDroneObjects1[0].getPointX("Centre")), (( gdjs.NewSceneCode.GDDroneObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDDroneObjects1[0].getPointY("Centre")), "");
}{for(var i = 0, len = gdjs.NewSceneCode.GDDroneObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDDroneObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.NewSceneCode.eventsList0x707bf4(runtimeScene);} //End of subevents
}

}


{

gdjs.NewSceneCode.GDBulletObjects1.createFrom(runtimeScene.getObjects("Bullet"));
gdjs.NewSceneCode.GDDroneObjects1.createFrom(runtimeScene.getObjects("Drone"));

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDBulletObjects1Objects, gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, false, runtimeScene, false);
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.NewSceneCode.GDBulletObjects1 */
/* Reuse gdjs.NewSceneCode.GDDroneObjects1 */
gdjs.NewSceneCode.GDExplosionObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDExplosionObjects1Objects, (( gdjs.NewSceneCode.GDDroneObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDDroneObjects1[0].getPointX("Centre")), (( gdjs.NewSceneCode.GDDroneObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDDroneObjects1[0].getPointY("Centre")), "");
}{for(var i = 0, len = gdjs.NewSceneCode.GDDroneObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDDroneObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDBulletObjects1[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.NewSceneCode.eventsList0x6fafe4(runtimeScene);} //End of subevents
}

}


{


{
gdjs.NewSceneCode.GDScoreObjects1.createFrom(runtimeScene.getObjects("Score"));
{for(var i = 0, len = gdjs.NewSceneCode.GDScoreObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDScoreObjects1[i].setString("Score : " + gdjs.evtTools.common.toString(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0))));
}
}}

}


{

gdjs.NewSceneCode.GDExplosionObjects1.createFrom(runtimeScene.getObjects("Explosion"));

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDExplosionObjects1.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDExplosionObjects1[i].hasAnimationEnded() ) {
        gdjs.NewSceneCode.condition0IsTrue_0.val = true;
        gdjs.NewSceneCode.GDExplosionObjects1[k] = gdjs.NewSceneCode.GDExplosionObjects1[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDExplosionObjects1.length = k;}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.NewSceneCode.GDExplosionObjects1 */
{for(var i = 0, len = gdjs.NewSceneCode.GDExplosionObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDExplosionObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.NewSceneCode.GDDroneObjects1.createFrom(runtimeScene.getObjects("Drone"));
gdjs.NewSceneCode.GDEchoObjects1.createFrom(runtimeScene.getObjects("Echo"));

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDDroneObjects1Objects, gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDEchoObjects1Objects, false, runtimeScene, false);
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.NewSceneCode.GDEchoObjects1 */
gdjs.NewSceneCode.GDExplosionObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDExplosionObjects1Objects, (( gdjs.NewSceneCode.GDEchoObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDEchoObjects1[0].getPointX("Centre")), (( gdjs.NewSceneCode.GDEchoObjects1.length === 0 ) ? 0 :gdjs.NewSceneCode.GDEchoObjects1[0].getPointY("Centre")), "");
}{for(var i = 0, len = gdjs.NewSceneCode.GDEchoObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDEchoObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


{
}

}


{


{
}

}


{


gdjs.NewSceneCode.condition0IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.NewSceneCode.condition0IsTrue_0.val) {
gdjs.NewSceneCode.GDGameOverObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDGameOverObjects1Objects, 318, 250, "");
}{for(var i = 0, len = gdjs.NewSceneCode.GDGameOverObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDGameOverObjects1[i].hide();
}
}}

}


{

gdjs.NewSceneCode.GDEchoObjects1.createFrom(runtimeScene.getObjects("Echo"));

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
gdjs.NewSceneCode.condition1IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.NewSceneCode.mapOfGDgdjs_46NewSceneCode_46GDEchoObjects1Objects) == 0;
}if ( gdjs.NewSceneCode.condition0IsTrue_0.val ) {
{
gdjs.NewSceneCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.1, "GameOver");
}}
if (gdjs.NewSceneCode.condition1IsTrue_0.val) {
gdjs.NewSceneCode.GDGameOverObjects1.createFrom(runtimeScene.getObjects("GameOver"));
{for(var i = 0, len = gdjs.NewSceneCode.GDGameOverObjects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDGameOverObjects1[i].hide(false);
}
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}}

}


{

gdjs.NewSceneCode.GDGameOverObjects1.createFrom(runtimeScene.getObjects("GameOver"));

gdjs.NewSceneCode.condition0IsTrue_0.val = false;
gdjs.NewSceneCode.condition1IsTrue_0.val = false;
gdjs.NewSceneCode.condition2IsTrue_0.val = false;
{
gdjs.NewSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimeScale(runtimeScene) == 0;
}if ( gdjs.NewSceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.NewSceneCode.GDGameOverObjects1.length;i<l;++i) {
    if ( gdjs.NewSceneCode.GDGameOverObjects1[i].isVisible() ) {
        gdjs.NewSceneCode.condition1IsTrue_0.val = true;
        gdjs.NewSceneCode.GDGameOverObjects1[k] = gdjs.NewSceneCode.GDGameOverObjects1[i];
        ++k;
    }
}
gdjs.NewSceneCode.GDGameOverObjects1.length = k;}if ( gdjs.NewSceneCode.condition1IsTrue_0.val ) {
{
gdjs.NewSceneCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right");
}}
}
if (gdjs.NewSceneCode.condition2IsTrue_0.val) {
gdjs.NewSceneCode.GDAltBack1Objects1.createFrom(runtimeScene.getObjects("AltBack1"));
gdjs.NewSceneCode.GDAltBack2Objects1.createFrom(runtimeScene.getObjects("AltBack2"));
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "NewScene", false);
}{for(var i = 0, len = gdjs.NewSceneCode.GDAltBack1Objects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDAltBack1Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.NewSceneCode.GDAltBack2Objects1.length ;i < len;++i) {
    gdjs.NewSceneCode.GDAltBack2Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


}; //End of gdjs.NewSceneCode.eventsList0xb4320


gdjs.NewSceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.NewSceneCode.GDEchoObjects1.length = 0;
gdjs.NewSceneCode.GDEchoObjects2.length = 0;
gdjs.NewSceneCode.GDDroneObjects1.length = 0;
gdjs.NewSceneCode.GDDroneObjects2.length = 0;
gdjs.NewSceneCode.GDBulletObjects1.length = 0;
gdjs.NewSceneCode.GDBulletObjects2.length = 0;
gdjs.NewSceneCode.GDBullet2Objects1.length = 0;
gdjs.NewSceneCode.GDBullet2Objects2.length = 0;
gdjs.NewSceneCode.GDExplosionObjects1.length = 0;
gdjs.NewSceneCode.GDExplosionObjects2.length = 0;
gdjs.NewSceneCode.GDGameOverObjects1.length = 0;
gdjs.NewSceneCode.GDGameOverObjects2.length = 0;
gdjs.NewSceneCode.GDScoreObjects1.length = 0;
gdjs.NewSceneCode.GDScoreObjects2.length = 0;
gdjs.NewSceneCode.GDAltBack2Objects1.length = 0;
gdjs.NewSceneCode.GDAltBack2Objects2.length = 0;
gdjs.NewSceneCode.GDAltBack1Objects1.length = 0;
gdjs.NewSceneCode.GDAltBack1Objects2.length = 0;
gdjs.NewSceneCode.GDBackgroundObjects1.length = 0;
gdjs.NewSceneCode.GDBackgroundObjects2.length = 0;
gdjs.NewSceneCode.GDIntroObjects1.length = 0;
gdjs.NewSceneCode.GDIntroObjects2.length = 0;
gdjs.NewSceneCode.GDNitroObjects1.length = 0;
gdjs.NewSceneCode.GDNitroObjects2.length = 0;
gdjs.NewSceneCode.GDBatteryObjects1.length = 0;
gdjs.NewSceneCode.GDBatteryObjects2.length = 0;
gdjs.NewSceneCode.GDStockObjects1.length = 0;
gdjs.NewSceneCode.GDStockObjects2.length = 0;
gdjs.NewSceneCode.GDTowerObjects1.length = 0;
gdjs.NewSceneCode.GDTowerObjects2.length = 0;
gdjs.NewSceneCode.GDHouseObjects1.length = 0;
gdjs.NewSceneCode.GDHouseObjects2.length = 0;

gdjs.NewSceneCode.eventsList0xb4320(runtimeScene);
return;

}
gdjs['NewSceneCode'] = gdjs.NewSceneCode;
